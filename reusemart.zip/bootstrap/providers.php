<?php

return [
    App\Providers\AppServiceProvider::class,
    App\Providers\CustomFilamentServiceProvider::class,
    App\Providers\Filament\AdminPanelProvider::class,
    App\Providers\Filament\OrganisasiPanelProvider::class,
    App\Providers\Filament\PegawaiAdminPanelProvider::class,
    App\Providers\Filament\PegawaiPanelProvider::class,
    App\Providers\Filament\PenitipPanelProvider::class,
    App\Providers\Filament\Penitip\PanelProvider::class,
];
